@extends('AdminLTE.re_usable_admin.datatable_layouts')
@section('title', 'Home')
@section('content')
@include('AdminLTE/re_usable_admin/dataTable_jQuery')


<div class="container-fluid card p-2">
<div class="text-left p-2">
sssssssss
</div>
</div> </div>


@endsection
